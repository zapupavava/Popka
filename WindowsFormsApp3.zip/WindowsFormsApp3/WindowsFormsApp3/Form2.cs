﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        private bool isPasswordVisible = false;
        public Form2()
        {
            InitializeComponent();
           
        }
       

        private void log_in_load(object sender, EventArgs e)
        {
            
            textBox1.MaxLength = 50;
            textBox2.MaxLength = 50;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataBase database = new DataBase();
            var LoginUser = textBox1.Text;
            var PassUser = textBox2.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            string queryString = $"Select id_user, login_user,password_user from register where login_user = '{LoginUser}'and password_user = '{PassUser}'";
            SqlCommand command = new SqlCommand(queryString, database.getConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);
            if (table.Rows.Count == 1)
            {
                MessageBox.Show("Вы успешно вошли!", "Успешно!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                

            }
            else
            { 
              MessageBox.Show("Такого аккаунта не существует!","Аккаунта не существует!",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 frm_sign = new Form1();
            frm_sign.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            isPasswordVisible = !isPasswordVisible;

            if (isPasswordVisible)
            {
                textBox2.PasswordChar = '\0'; // Отображаем текст
                button2.Text = "Скрыть"; // Изменяем текст на кнопке для понятности
            }
            else
            {
                textBox2.PasswordChar = '*'; // Скрываем текст
                button2.Text = "Показать";

            }
        }
    }
}
